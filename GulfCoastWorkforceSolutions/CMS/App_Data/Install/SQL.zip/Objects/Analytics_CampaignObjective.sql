SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Analytics_CampaignObjective](
	[CampaignObjectiveID] [int] IDENTITY(1,1) NOT NULL,
	[CampaignObjectiveGuid] [uniqueidentifier] NOT NULL,
	[CampaignObjectiveLastModified] [datetime2](7) NOT NULL,
	[CampaignObjectiveCampaignID] [int] NOT NULL,
	[CampaignObjectiveValue] [int] NULL,
	[CampaignObjectiveCampaignConversionID] [int] NOT NULL,
 CONSTRAINT [PK_Analytics_CampaignObjective] PRIMARY KEY CLUSTERED 
(
	[CampaignObjectiveID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON),
 CONSTRAINT [CK_Analytics_CampaignObjective_CampaignObjectiveCampaignID] UNIQUE NONCLUSTERED 
(
	[CampaignObjectiveCampaignID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_Analytics_CampaignObjective_CampaignObjectiveCampaignConversionID] ON [dbo].[Analytics_CampaignObjective]
(
	[CampaignObjectiveCampaignConversionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Analytics_CampaignObjective] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignObjective_CampaignObjectiveGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [CampaignObjectiveGuid]
GO
ALTER TABLE [dbo].[Analytics_CampaignObjective] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignObjective_CampaignObjectiveLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [CampaignObjectiveLastModified]
GO
ALTER TABLE [dbo].[Analytics_CampaignObjective] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignObjective_CampaignObjectiveCampaignID]  DEFAULT ((0)) FOR [CampaignObjectiveCampaignID]
GO
ALTER TABLE [dbo].[Analytics_CampaignObjective] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignObjective_CampaignObjectiveCampaignConversionID]  DEFAULT ((0)) FOR [CampaignObjectiveCampaignConversionID]
GO
ALTER TABLE [dbo].[Analytics_CampaignObjective]  WITH CHECK ADD  CONSTRAINT [FK_Analytics_CampaignObjective_CampaignObjectiveCampaignConversionID_Analytics_CampaignConversion] FOREIGN KEY([CampaignObjectiveCampaignConversionID])
REFERENCES [dbo].[Analytics_CampaignConversion] ([CampaignConversionID])
GO
ALTER TABLE [dbo].[Analytics_CampaignObjective] CHECK CONSTRAINT [FK_Analytics_CampaignObjective_CampaignObjectiveCampaignConversionID_Analytics_CampaignConversion]
GO
ALTER TABLE [dbo].[Analytics_CampaignObjective]  WITH CHECK ADD  CONSTRAINT [FK_Analytics_CampaignObjective_CampaignObjectiveCampaignID_Analytics_Campaign] FOREIGN KEY([CampaignObjectiveCampaignID])
REFERENCES [dbo].[Analytics_Campaign] ([CampaignID])
GO
ALTER TABLE [dbo].[Analytics_CampaignObjective] CHECK CONSTRAINT [FK_Analytics_CampaignObjective_CampaignObjectiveCampaignID_Analytics_Campaign]
GO
