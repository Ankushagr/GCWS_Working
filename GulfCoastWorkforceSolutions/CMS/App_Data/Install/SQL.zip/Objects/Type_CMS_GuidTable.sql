CREATE TYPE [dbo].[Type_CMS_GuidTable] AS TABLE(
	[Value] [uniqueidentifier] NULL
)
GO
