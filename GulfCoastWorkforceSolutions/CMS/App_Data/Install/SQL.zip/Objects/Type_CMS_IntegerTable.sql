CREATE TYPE [dbo].[Type_CMS_IntegerTable] AS TABLE(
	[Value] [int] NULL
)
GO
