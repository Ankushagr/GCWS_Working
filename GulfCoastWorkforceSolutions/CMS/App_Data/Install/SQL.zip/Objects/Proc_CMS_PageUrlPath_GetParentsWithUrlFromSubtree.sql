SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_PageUrlPath_GetParentsWithUrlFromSubtree]
	@NodeID INT,
	@SiteID INT
AS
BEGIN
    DECLARE @SiteTypes TABLE(
        [ID] INT NOT NULL, 
        [HasUrl] BIT NOT NULL)

    INSERT INTO @SiteTypes 
        SELECT 
            [ClassID], 
            [ClassHasURL] 
        FROM [CMS_Class] 
        WHERE [ClassID] IN (SELECT [ClassID] FROM [CMS_ClassSite] WHERE [SiteID] = @SiteID)

    ;WITH parentsWithUrl AS (
        SELECT 
			[NodeID], 
			[HasUrl]
        FROM [CMS_Tree] INNER JOIN @SiteTypes ON [NodeClassID] = [ID]
        WHERE NodeID = @NodeID

        UNION ALL

        SELECT 
			[T].[NodeID], 
			[F].[HasUrl]
        FROM [CMS_Tree] [T] 
		INNER JOIN parentsWithUrl [P] ON [P].[NodeID] = [T].NodeParentID AND [P].[HasUrl] = 0 
		INNER JOIN @SiteTypes [F] ON [NodeClassID] = [ID] 
    )
    SELECT [NodeID] FROM parentsWithUrl WHERE [HasUrl] = 1
END
GO
